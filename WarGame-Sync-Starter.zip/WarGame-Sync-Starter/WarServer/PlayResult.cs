﻿namespace WarServer
{
    public enum PlayResult
    {
        Win,
        Draw,
        Lose
    }
}