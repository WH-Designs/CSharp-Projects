﻿namespace WarClient
{
    public enum CommandProtocol
    {
        WantGame,
        GameStart,
        PlayCard,
        PlayResult,
        EndGame
    }
}