﻿namespace WarClient
{
    public enum PlayResult
    {
        Win,
        Draw,
        Lose
    }
}